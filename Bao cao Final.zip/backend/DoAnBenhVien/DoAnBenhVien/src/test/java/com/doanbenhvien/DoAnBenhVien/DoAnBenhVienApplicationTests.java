package com.doanbenhvien.DoAnBenhVien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoAnBenhVienApplicationTests {

	@Test
	void contextLoads() {
	}

}
