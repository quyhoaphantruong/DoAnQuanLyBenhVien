package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class DanhMucDieuTriDTO {
    private Integer idDanhMucDieuTri;
    private String tenDanhMuc;
}
