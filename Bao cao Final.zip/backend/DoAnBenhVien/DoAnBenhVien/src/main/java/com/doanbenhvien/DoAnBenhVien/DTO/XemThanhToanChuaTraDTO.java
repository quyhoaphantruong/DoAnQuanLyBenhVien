package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class XemThanhToanChuaTraDTO {
    private Integer idKeHoachDieuTri;
    private Long tienConThieu;
}
