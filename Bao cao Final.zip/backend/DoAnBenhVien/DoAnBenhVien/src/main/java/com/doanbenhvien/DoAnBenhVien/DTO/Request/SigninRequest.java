package com.doanbenhvien.DoAnBenhVien.DTO.Request;

import lombok.Data;

@Data
public class SigninRequest {
    private String soDienThoai;
    private String matKhau;
}
