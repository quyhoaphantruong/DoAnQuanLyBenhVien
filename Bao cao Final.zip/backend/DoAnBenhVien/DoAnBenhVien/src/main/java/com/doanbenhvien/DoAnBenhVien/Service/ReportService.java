package com.doanbenhvien.DoAnBenhVien.Service;

import org.springframework.stereotype.Service;

@Service
public class ReportService {
}
