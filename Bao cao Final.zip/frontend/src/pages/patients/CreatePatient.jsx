function CreatePatient() {
  return <div>CreatePatient</div>;
}

export default CreatePatient;
