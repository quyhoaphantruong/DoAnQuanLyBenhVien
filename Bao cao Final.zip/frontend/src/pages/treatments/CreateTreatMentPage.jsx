import KeHoachDieuTri from "../../components/treatments/KeHoachDieuTri";
import TreatmentsComponent from "../../components/treatments/Treatment";

function CreateTreatMentPage() {
  return (
    <div>
      <KeHoachDieuTri />
      <TreatmentsComponent />
    </div>
  );
}

export default CreateTreatMentPage;
