function StaffPage() {
  return <div>StaffPage</div>;
}

export default StaffPage;
