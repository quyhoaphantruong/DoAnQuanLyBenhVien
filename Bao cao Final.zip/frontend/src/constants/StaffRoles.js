export const nhanVienRoles = ["Quản trị viên", "Nha sĩ", "Nhân viên"];
