package com.doanbenhvien.DoAnBenhVien.DTO.Response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse {
    private String error;
}
