package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class KeHoachDieuTriCuTheDTO {
    private String tenRang;
    private String tenMat;
    private String tenDieuTri;
    private Integer phi;
}
