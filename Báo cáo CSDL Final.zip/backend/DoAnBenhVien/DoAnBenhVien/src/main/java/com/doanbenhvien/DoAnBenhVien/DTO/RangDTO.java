package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class RangDTO {
    private byte idRang;
    private String tenRang;
}
