package com.doanbenhvien.DoAnBenhVien.DTO.Request;

import lombok.Data;

@Data
public class CapNhatKeHoachDieuTriDTO {
    int idKehoachDieuTri;
    String noiDung;
    String chanDoan;
    int tinhTrangDieuTri;
}
