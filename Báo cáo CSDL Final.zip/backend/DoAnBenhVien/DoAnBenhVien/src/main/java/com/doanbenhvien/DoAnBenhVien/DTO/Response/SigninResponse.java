package com.doanbenhvien.DoAnBenhVien.DTO.Response;

import lombok.Data;

@Data
public class SigninResponse {
    private String ten;
    private String soDienThoai;
    private String loaiNhanVien;
}
