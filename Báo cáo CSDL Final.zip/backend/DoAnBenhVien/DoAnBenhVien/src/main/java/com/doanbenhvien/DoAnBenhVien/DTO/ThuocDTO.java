package com.doanbenhvien.DoAnBenhVien.DTO;
import lombok.Data;

@Data
public class ThuocDTO {
    private Integer idThuoc;
    private String tenThuoc;
    private Integer phi;
    private String donViTinh;
}
