package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class MatDTO {
    private char loaiMat;
    private String tenMat;
}
