package com.doanbenhvien.DoAnBenhVien.DTO.Request;

import lombok.Data;

@Data
public class BenhNhanRequest {
    private String soDienThoai;
    private String matKhau;
    private String ten;
    private String email;
    private String gioiTinh;
}
