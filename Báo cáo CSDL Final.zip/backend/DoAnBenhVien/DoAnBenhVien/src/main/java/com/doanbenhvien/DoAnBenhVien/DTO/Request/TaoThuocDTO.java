package com.doanbenhvien.DoAnBenhVien.DTO.Request;

import lombok.Data;

@Data
public class TaoThuocDTO {
    private String tenThuoc;
    private String donViTinh;
    private Integer phi;
}
