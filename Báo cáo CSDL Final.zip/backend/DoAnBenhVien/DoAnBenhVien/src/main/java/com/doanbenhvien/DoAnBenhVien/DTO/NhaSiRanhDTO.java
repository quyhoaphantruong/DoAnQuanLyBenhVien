package com.doanbenhvien.DoAnBenhVien.DTO;

import lombok.Data;

@Data
public class NhaSiRanhDTO {
    private Integer idNhanVien;
    private String ten;
    private Integer daKham;
}
