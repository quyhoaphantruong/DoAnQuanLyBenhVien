function HomePage() {
  return (
    <>
      <div>Homepage</div>
    </>
  );
}

export default HomePage;
