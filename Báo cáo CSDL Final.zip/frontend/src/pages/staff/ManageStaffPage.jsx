function ManageStaffPage() {
  return <div>ManageStaffPage</div>;
}

export default ManageStaffPage;
