function AppointmentsPage() {
  return <div>AppointmentsPage</div>;
}

export default AppointmentsPage;
