const mockTeeth = [
  { id: 1, name: "Tooth 1" },
  { id: 2, name: "Tooth 2" },
  { id: 3, name: "Tooth 3" },
  // Add more teeth as needed
];

const mockFacialTypes = [
  { id: 1, name: "Facial Type 1" },
  { id: 2, name: "Facial Type 2" },
  { id: 3, name: "Facial Type 3" },
  // Add more facial types as needed
];

export { mockTeeth, mockFacialTypes };
