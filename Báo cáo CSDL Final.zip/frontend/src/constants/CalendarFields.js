export const calendarFields = [
  {
    label: "ID Nhân viên",
    type: "text",
    name: "idNhanVien",
  },
  {
    label: "Giờ bắt đầu",
    type: "datetime",
    name: "gioBatDau",
  },
  {
    label: "Giờ kết thúc",
    type: "datetime",
    name: "gioKetThuc",
  },
  {
    label: "Phòng khám",
    type: "text",
    name: "phongKham",
  },
];
