export const patientFields = [
  {
    label: "Tên",
    type: "text",
    name: "ten",
  },
  {
    label: "Mật khẩu",
    type: "password",
    name: "matKhau",
  },
  {
    label: "Email",
    type: "text",
    name: "email",
  },
  {
    label: "Giới tính",
    type: "text",
    name: "gioiTinh",
  },
  {
    label: "Số điện thoại",
    type: "text",
    name: "soDienThoai",
  },
];
